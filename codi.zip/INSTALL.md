# Installation

Currently, r2syntia.py is provided as a single file script.

A Dockerfile is included to ease the installation process. It will build a container with all the tools, requirements and test files placed in `/opt` folder.

## Manual installation

We assume a GNU/Linux system with python3 installation; python2 support is not guaranteed.

### radare2
```
git clone https://github.com/radareorg/radare2.git
cd radare2
./sys/install.sh
```

#### r2pipe
```
pip3 install r2pipe
```


### Syntia
#### requirements

```
pip3 install orderedset
pip3 install z3-solver
```

Currently our modified version of Syntia is assumed to be placed in the same directory as r2syntia.py script. However, it could be easily installed as a system-wide python module.
